//
//  IGApplicationForm.h
//  ProgrammingTest1
//
//  Created by IG Group on 10/05/2013.
//  Copyright (c) 2013 IG Group. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    IGApplicationFormFieldFirstName,
    IGApplicationFormFieldMiddleName,
    IGApplicationFormFieldSurname,
    IGApplicationFormFieldAddress,
    IGApplicationFormFieldPhoneNumber,
    IGApplicationFormFieldMax
} IGApplicationFormField;

@interface IGApplicationForm : NSObject

@property (nonatomic,retain) NSString *firstName;
@property (nonatomic,retain) NSString *middleName;
@property (nonatomic,retain) NSString *surname;
@property (nonatomic,retain) NSString *address;
@property (nonatomic,retain) NSString *phoneNumber;

+ (NSString *) nameForField:(IGApplicationFormField)field;
- (NSArray *) allObjectValues;
+ (NSArray *) allKeys;

@end
