//
//  IGApplicationForm.h
//  ProgrammingTest1
//
//  Created by Daniel Broad on 10/05/2013.
//  Copyright (c) 2013 Daniel Broad. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IGApplicationForm : NSObject

@property (nonatomic,retain) NSString *firstName;

@end
