//
//  IGApplicationForm.m
//  ProgrammingTest1
//
//  Created by IG Group on 10/05/2013.
//  Copyright (c) 2013 IG Group. All rights reserved.
//

#import "IGApplicationForm.h"

@implementation IGApplicationForm

-(void) dealloc {
    [_firstName release];
    [_middleName release];
    [_surname release];
    [_address release];
    [super dealloc];
}

- (id) init {
    self = [super init];
    if (self) {
        _firstName = @"";
        _middleName = @"";
        _surname = @"";
        _address = @"";
        _phoneNumber = @"";
    }
    return self;
}


+ (NSString *) nameForField:(IGApplicationFormField)field {
    switch (field) {
        case IGApplicationFormFieldFirstName:
            return @"First Name";
            break;
        case IGApplicationFormFieldMiddleName:
            return @"Middle Name";
            break;
        case IGApplicationFormFieldSurname:
            return @"Surname";
            break;
        case IGApplicationFormFieldAddress:
            return @"Address";
            break;
        case IGApplicationFormFieldPhoneNumber:
            return @"Phone number";
            break;
        default:
            return @"na";
            break;
    }
}

- (NSArray *) allObjectValues {
    return [NSArray arrayWithObjects:self.firstName, self.middleName, self.surname, self.address, self.phoneNumber, nil];
}

+ (NSArray *) allKeys {
    return [NSArray arrayWithObjects:@"firstName", @"middleName", @"surName", @"address", @"phoneNumber", nil];
}

@end
