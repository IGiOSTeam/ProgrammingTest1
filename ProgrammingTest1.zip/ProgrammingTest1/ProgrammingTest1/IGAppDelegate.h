//
//  IGAppDelegate.h
//  ProgrammingTest1
//
//  Created by IG Group on 10/05/2013.
//  Copyright (c) 2013 IG Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IGRootViewController;

@interface IGAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic,retain) UIWindow *window;

@property (nonatomic,retain) IGRootViewController *viewController;
@property (nonatomic,retain) UINavigationController *navigationController;
@end
