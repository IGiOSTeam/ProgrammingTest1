//
//  IGAppDelegate.h
//  ProgrammingTest1
//
//  Created by Daniel Broad on 10/05/2013.
//  Copyright (c) 2013 Daniel Broad. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IGApplicationFormViewController;

@interface IGAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic,retain) UIWindow *window;

@property (nonatomic,retain) IGApplicationFormViewController *viewController;

@end
