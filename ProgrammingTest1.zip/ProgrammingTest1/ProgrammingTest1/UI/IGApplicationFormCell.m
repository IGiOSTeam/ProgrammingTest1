//
//  IGApplicationFormCell.m
//  ProgrammingTest1
//
//  Created by IG Group on 10/05/2013.
//  Copyright (c) 2013 IG Group. All rights reserved.
//

#import "IGApplicationFormCell.h"

@class IGApplicationForm;

@interface IGApplicationFormCell () <UITextFieldDelegate>

@property (nonatomic,retain) UITextField* textField;
@property (nonatomic, assign) IGApplicationFormField fieldId;
@property (nonatomic,retain) IGApplicationForm *modelObject;
@end

@implementation IGApplicationFormCell

#pragma mark - Init

- (id)initWithModelObject:(IGApplicationForm *) object fieldNumber:(IGApplicationFormField)fieldId reuseIdentifier: (NSString*) reuseIdentifier {
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.modelObject = object;
        self.textLabel.text = [IGApplicationForm nameForField:fieldId];
        self.fieldId = fieldId;
        
        // add textfield
        self.textField = [[[UITextField alloc] init] autorelease];
        [self.contentView addSubview:self.textField];
        self.textField.text = [[object allObjectValues] objectAtIndex:fieldId];
        self.textField.delegate = self;
        self.textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.textField.font = [UIFont systemFontOfSize:14.0f];

    }
    return self;
}

-(void) layoutSubviews {
    [super layoutSubviews];
    self.textField.frame = CGRectMake(160, 12, 130, 20);
}

#pragma mark - UITextFieldDelegate


- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    NSString *key = [[IGApplicationForm allKeys] objectAtIndex:self.fieldId];
    [self.modelObject setValue: textField.text forKey:key];
    self.textField.text = [self.modelObject valueForKey:key];
    [textField resignFirstResponder];
}

@end
