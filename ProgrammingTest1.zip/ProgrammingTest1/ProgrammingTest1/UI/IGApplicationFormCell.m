//
//  IGApplicationFormCell.m
//  ProgrammingTest1
//
//  Created by Daniel Broad on 10/05/2013.
//  Copyright (c) 2013 Daniel Broad. All rights reserved.
//

#import "IGApplicationFormCell.h"

@class IGApplicationForm;

@interface IGApplicationFormCell () <UITextFieldDelegate>

@property (nonatomic,retain) UITextField* textField;
@property (nonatomic,retain) NSString *fieldName;
@property (nonatomic,retain) IGApplicationForm *modelObject;
@end

@implementation IGApplicationFormCell

#pragma mark - Init

- (id)initWithModelObject: (id) object fieldName: (NSString*) fieldName reuseIdentifier: (NSString*) reuseIdentifier {
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.modelObject = object;
        self.fieldName = fieldName;
        
        self.textLabel.text = fieldName;
        
        // add textfield
        self.textField = [[[UITextField alloc] init] autorelease];
        [self.contentView addSubview:self.textField];
        self.textField.text = [object valueForKey:fieldName];
        self.textField.delegate = self;
        self.textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.textField.font = [UIFont systemFontOfSize:14.0f];

    }
    return self;
}

-(void) layoutSubviews {
    [super layoutSubviews];
    self.textField.frame = CGRectMake(160, 12, 130, 20);
}

#pragma mark - UITextFieldDelegate


- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if ([textField.text length]) {
        [self.modelObject setValue: textField.text forKey:self.fieldName];
    } else {
        self.textField.text = [self.modelObject valueForKey:self.fieldName];
    }
    [textField resignFirstResponder];
}

@end
