//
//  IGRootViewController.m
//  ProgrammingTest1
//
//  Created by Daniel Broad on 13/05/2013.
//  Copyright (c) 2013 Daniel Broad. All rights reserved.
//

#import "IGRootViewController.h"
#import "IGApplicationFormViewController.h"

@interface IGRootViewController ()
@property (nonatomic,retain) UIButton *applyButton;
@end

@implementation IGRootViewController

-(void) dealloc {
    [_applyButton release];
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.applyButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [self.applyButton setFrame:CGRectMake(10, 50, 300, 44)];
        [self.applyButton setTitle:NSLocalizedString(@"Apply", nil) forState:UIControlStateNormal];
        [self.applyButton addTarget:self action:@selector(apply:) forControlEvents:UIControlEventTouchUpInside];
        self.title = NSLocalizedString(@"Tap apply", nil);
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor lightGrayColor];
	[self.view addSubview:self.applyButton];
}

#pragma mark - methods

-(void) apply: (id) sender {
    IGApplicationFormViewController *appForm = [[IGApplicationFormViewController alloc] init];
    [self.navigationController pushViewController:appForm animated:YES];
    [appForm release];
}


@end
