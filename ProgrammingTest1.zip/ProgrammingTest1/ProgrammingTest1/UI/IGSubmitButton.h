//
//  IGSubmitButton.h
//  ProgrammingTest1
//
//  Created by IG Group on 13/05/2013.
//  Copyright (c) 2013 IG Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IGSubmitButton : UIButton

@end
