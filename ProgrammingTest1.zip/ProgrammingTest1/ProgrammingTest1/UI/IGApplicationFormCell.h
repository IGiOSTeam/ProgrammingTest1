//
//  IGApplicationFormCell.h
//  ProgrammingTest1
//
//  Created by IG Group on 10/05/2013.
//  Copyright (c) 2013 IG Group. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IGApplicationForm.h"

@interface IGApplicationFormCell : UITableViewCell

- (id)initWithModelObject:(IGApplicationForm *) object fieldNumber:(IGApplicationFormField)fieldId reuseIdentifier: (NSString*) reuseIdentifier;


@end
