//
//  IGViewController.m
//  ProgrammingTest1
//
//  Created by Daniel Broad on 10/05/2013.
//  Copyright (c) 2013 Daniel Broad. All rights reserved.
//

#import "IGApplicationFormViewController.h"
#import "IGApplicationFormCell.h"
#import "IGApplicationForm.h"
#import "IGSubmitButton.h"

@interface IGApplicationFormViewController () <UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,retain) IGApplicationForm *applicationForm;
@property (nonatomic,retain) IGSubmitButton *submitButton;
@end

@implementation IGApplicationFormViewController

#pragma mark - Memory Managment

- (id) init {
    self = [super initWithStyle: UITableViewStyleGrouped];
    if (self) {
        // initialisation
        self.submitButton = [[IGSubmitButton alloc] initWithFrame:CGRectMake(10, 0, 300, 44)];
        [self.submitButton addTarget:self action:@selector(submitForm:) forControlEvents:UIControlEventTouchUpInside];
        UIView *footer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
        [footer addSubview:self.submitButton];
        self.tableView.tableFooterView = footer;
    }
    return self;
}

#pragma mark - View Lifecycle


#pragma mark - UITableViewDelegate

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

-(NSString*) tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return NSLocalizedString(@"Welcome to IG", nil);
}

-(NSString*) tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    return NSLocalizedString(@"Please fill in your details", nil);
}

-(UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *reuseIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (!cell) {
        cell = [[IGApplicationFormCell alloc] initWithModelObject:self.applicationForm fieldName:@"firstName" reuseIdentifier:@"Cell"];
    }
    
    return cell;
}

#pragma mark - form submission

-(void) submitForm: (id) sender {
    
}
@end
