//
//  IGViewController.m
//  ProgrammingTest1
//
//  Created by IG Group on 10/05/2013.
//  Copyright (c) 2013 IG Group. All rights reserved.
//

#import "IGApplicationFormViewController.h"
#import "IGApplicationFormCell.h"
#import "IGApplicationForm.h"
#import "IGSubmitButton.h"
#import <MessageUI/MFMailComposeViewController.h>

@interface IGApplicationFormViewController () <UITableViewDelegate,UITableViewDataSource,MFMailComposeViewControllerDelegate>
@property (nonatomic,retain) IGApplicationForm *applicationForm;
@property (nonatomic,retain) IGSubmitButton *submitButton;
@end

@implementation IGApplicationFormViewController

#pragma mark - Memory Managment

- (void) dealloc {
    [_applicationForm release];
    [super dealloc];
}

- (id) init {
    self = [super initWithStyle: UITableViewStyleGrouped];
    if (self) {
        // initialisation
        self.submitButton = [[IGSubmitButton alloc] initWithFrame:CGRectMake(10, 0, 300, 44)];
        [self.submitButton addTarget:self action:@selector(submitForm:) forControlEvents:UIControlEventTouchUpInside];
        UIView *footer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
        [footer addSubview:self.submitButton];
        self.tableView.tableFooterView = footer;
        _applicationForm = [[IGApplicationForm alloc] init];
        self.title = NSLocalizedString(@"Application Form", nil);
    }
    return self;
}

#pragma mark - View Lifecycle


#pragma mark - UITableViewDelegate

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

-(NSString*) tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return NSLocalizedString(@"Welcome to IG", nil);
}

-(NSString*) tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    return NSLocalizedString(@"Please fill in your details", nil);
}

-(UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *reuseIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (!cell) {
        cell = [[IGApplicationFormCell alloc] initWithModelObject:self.applicationForm fieldNumber:indexPath.row reuseIdentifier:reuseIdentifier];
    }
    
    return cell;
}

#pragma mark - form submission

-(void) submitForm: (id) sender {
    
    // Could be done different way, for now do this to resign first responder to get object updated with last edited text field
    [self.tableView reloadData];
    
    if ([MFMailComposeViewController canSendMail]) {
        // Show the composer
    } else {
        // Handle the error
    }
    MFMailComposeViewController* controller = [[MFMailComposeViewController alloc] init];
    controller.mailComposeDelegate = self;
    [controller setSubject:@"Welcome to IG"];
    [controller setToRecipients:[NSArray arrayWithObject:@"aliosteam@iggroup.com"]];
    
    NSArray *values = [self.applicationForm allObjectValues];
    NSString *body = nil;
    for (NSInteger i = 0; i < [values count]; ++i) {
        body = [NSString stringWithFormat:@"%@%@: %@\n", body ? body:@"", [IGApplicationForm nameForField:(IGApplicationFormField)i], [values objectAtIndex:i]];
    }
    
    [controller setMessageBody:body isHTML:NO];
    if (controller) {
        [self presentViewController:controller animated:YES completion:^{
            
        }];
    }
    [controller release];
    
    
}

- (void)mailComposeController:(MFMailComposeViewController*)controller
          didFinishWithResult:(MFMailComposeResult)result
                        error:(NSError*)error;
{
    [self dismissViewControllerAnimated:YES completion:^{
        if (result == MFMailComposeResultSent) {
            NSLog(@"Sent");
        }
    }];
}
@end
