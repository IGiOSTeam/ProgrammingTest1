//
//  ProgrammingTest1Tests.m
//  ProgrammingTest1Tests
//
//  Created by IG Group on 10/05/2013.
//  Copyright (c) 2013 IG Group. All rights reserved.
//

#import "ProgrammingTest1Tests.h"

@implementation ProgrammingTest1Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in ProgrammingTest1Tests");
}

@end
